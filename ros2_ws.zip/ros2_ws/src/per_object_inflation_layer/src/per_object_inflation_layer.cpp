#include "per_object_inflation_layer/per_object_inflation_layer.hpp"
#include <cmath>
#include <algorithm>
namespace per_object_inflation_layer
{
PerObjectInflationLayer::PerObjectInflationLayer()
: cost_scaling_factor_(3.0),
  use_tf_(true)
{
}
void PerObjectInflationLayer::onInitialize()
{
  auto node = node_;
  if (!node) {
    throw std::runtime_error("[PerObjectInflationLayer] node_ not set");
  }
  // Frame this layer writes into
  target_frame_ = layered_costmap_->getGlobalFrameID();
  // Declare params (namespaced under this plugin key)
  declareParameter("objects_topic", rclcpp::ParameterValue(std::string("/per_object_inflation")));
  declareParameter("cost_scaling_factor", rclcpp::ParameterValue(3.0));
  declareParameter("use_tf", rclcpp::ParameterValue(true));
  // Read using fully-qualified plugin param names
  const auto p_topic_key = getFullName("objects_topic");
  const auto p_k_key     = getFullName("cost_scaling_factor");
  const auto p_tf_key    = getFullName("use_tf");
  // Safe getters with defaults if missing
  if (!node->get_parameter(p_topic_key, topic_)) {
    topic_ = "/per_object_inflation";
  }
  if (!node->get_parameter(p_k_key, cost_scaling_factor_)) {
    cost_scaling_factor_ = 3.0;
  }
  if (!node->get_parameter(p_tf_key, use_tf_)) {
    use_tf_ = true;
  }
  if (use_tf_) {
    tf_buffer_   = std::make_shared<tf2_ros::Buffer>(node->get_clock());
    tf_listener_ = std::make_shared<tf2_ros::TransformListener>(*tf_buffer_);
  }
  sub_ = node->create_subscription<per_object_inflation_msgs::msg::PerObjectInflationArray>(
    topic_, rclcpp::SystemDefaultsQoS(),
    std::bind(&PerObjectInflationLayer::objectsCallback, this, std::placeholders::_1));
  enabled_ = true;
  current_ = true;
  RCLCPP_INFO(node->get_logger(),
    "[PerObjectInflationLayer] frame=%s topic=%s k=%.3f use_tf=%s",
    target_frame_.c_str(), topic_.c_str(), cost_scaling_factor_, use_tf_ ? "true" : "false");
}
void PerObjectInflationLayer::objectsCallback(
  const per_object_inflation_msgs::msg::PerObjectInflationArray::SharedPtr msg)
{
  std::lock_guard<std::mutex> lk(mtx_);
  objects_.clear();
  const std::string src_frame = msg->header.frame_id;
  const bool need_tf = use_tf_ && !src_frame.empty() && (src_frame != target_frame_);
  geometry_msgs::msg::PoseStamped ps_in, ps_out;
  ps_in.pose.orientation.w = 1.0;
  for (const auto & o : msg->objects) {
    double x = o.center.x;
    double y = o.center.y;
    double r = std::max(0.0, static_cast<double>(o.radius));
    if (need_tf && tf_buffer_) {
      try {
        ps_in.header = msg->header;
        ps_in.pose.position.x = x;
        ps_in.pose.position.y = y;
        tf_buffer_->transform(ps_in, ps_out, target_frame_, tf2::durationFromSec(0.2));
        x = ps_out.pose.position.x;
        y = ps_out.pose.position.y;
      } catch (const tf2::TransformException &ex) {
        if (node_) {
          RCLCPP_WARN_THROTTLE(node_->get_logger(), *node_->get_clock(), 2000,
            "[PerObjectInflationLayer] TF %s -> %s failed: %s",
            src_frame.c_str(), target_frame_.c_str(), ex.what());
        }
        continue; // skip this object if cannot transform
      }
    }
    objects_.push_back(Obj{x, y, r});
  }
  current_ = true;
}
void PerObjectInflationLayer::updateBounds(
  double /*robot_x*/, double /*robot_y*/, double /*robot_yaw*/,
  double *min_x, double *min_y, double *max_x, double *max_y)
{
  if (!enabled_) return;
  std::lock_guard<std::mutex> lk(mtx_);
  for (const auto & o : objects_) {
    *min_x = std::min(*min_x, o.x - o.radius);
    *min_y = std::min(*min_y, o.y - o.radius);
    *max_x = std::max(*max_x, o.x + o.radius);
    *max_y = std::max(*max_y, o.y + o.radius);
  }
}
// Simple exponential decay similar to inflation semantics
static inline unsigned char decay_cost(double dist_m, double k)
{
  if (dist_m <= 0.0) return nav2_costmap_2d::LETHAL_OBSTACLE - 1; // 252..253 near center
  double c = 253.0 * std::exp(-k * dist_m);
  if (c < 1.0) c = 1.0;
  if (c > 253.0) c = 253.0;
  return static_cast<unsigned char>(c);
}
void PerObjectInflationLayer::inflateObject(
  nav2_costmap_2d::Costmap2D & master_grid, const Obj & o)
{
  const double res = master_grid.getResolution();
  const int radius_cells = static_cast<int>(std::ceil(o.radius / res));
  unsigned int cx = 0, cy = 0;
  if (!master_grid.worldToMap(o.x, o.y, cx, cy)) {
    return; // object center outside the map
  }
  const int size_x = static_cast<int>(master_grid.getSizeInCellsX());
  const int size_y = static_cast<int>(master_grid.getSizeInCellsY());
  const int min_i = std::max(0, static_cast<int>(cx) - radius_cells);
  const int max_i = std::min(size_x - 1, static_cast<int>(cx) + radius_cells);
  const int min_j = std::max(0, static_cast<int>(cy) - radius_cells);
  const int max_j = std::min(size_y - 1, static_cast<int>(cy) + radius_cells);
  for (int j = min_j; j <= max_j; ++j) {
    for (int i = min_i; i <= max_i; ++i) {
      const double wx = master_grid.getOriginX() + (i + 0.5) * res;
      const double wy = master_grid.getOriginY() + (j + 0.5) * res;
      const double dx = wx - o.x;
      const double dy = wy - o.y;
      const double dist = std::sqrt(dx*dx + dy*dy);
      if (dist > o.radius) continue;
      const unsigned char c = decay_cost(dist, cost_scaling_factor_);
      const unsigned char prev = master_grid.getCost(i, j);
      if (c > prev) {
        master_grid.setCost(i, j, c);
      }
    }
  }
}
void PerObjectInflationLayer::updateCosts(
  nav2_costmap_2d::Costmap2D & master_grid,
  int /*min_i*/, int /*min_j*/, int /*max_i*/, int /*max_j*/)
{
  if (!enabled_) return;
  std::lock_guard<std::mutex> lk(mtx_);
  for (const auto & o : objects_) {
    inflateObject(master_grid, o);
  }
}
void PerObjectInflationLayer::reset()
{
  std::lock_guard<std::mutex> lk(mtx_);
  objects_.clear();
  current_ = true;
  enabled_ = true;
}
}  // namespace per_object_inflation_layer
PLUGINLIB_EXPORT_CLASS(per_object_inflation_layer::PerObjectInflationLayer,
                       nav2_costmap_2d::Layer)

