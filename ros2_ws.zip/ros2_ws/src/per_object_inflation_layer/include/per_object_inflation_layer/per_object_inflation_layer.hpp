#ifndef PER_OBJECT_INFLATION_LAYER__PER_OBJECT_INFLATION_LAYER_HPP_
#define PER_OBJECT_INFLATION_LAYER__PER_OBJECT_INFLATION_LAYER_HPP_
#include <mutex>
#include <vector>
#include <string>
#include "rclcpp/rclcpp.hpp"
#include "nav2_costmap_2d/layer.hpp"
#include "nav2_costmap_2d/costmap_2d.hpp"
#include "pluginlib/class_list_macros.hpp"
#include "geometry_msgs/msg/point.hpp"
#include "per_object_inflation_msgs/msg/per_object_inflation_array.hpp"
// TF2 for frame conversion
#include "tf2_ros/buffer.h"
#include "tf2_ros/transform_listener.h"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
namespace per_object_inflation_layer
{
struct Obj
{
  double x;
  double y;
  double radius;   // [m]
};
class PerObjectInflationLayer : public nav2_costmap_2d::Layer
{
public:
  PerObjectInflationLayer();
  ~PerObjectInflationLayer() override = default;
  void onInitialize() override;
  void updateBounds(double robot_x, double robot_y, double robot_yaw,
                    double *min_x, double *min_y, double *max_x, double *max_y) override;
  void updateCosts(nav2_costmap_2d::Costmap2D & master_grid,
                   int min_i, int min_j, int max_i, int max_j) override;
  void reset() override;
private:
  void objectsCallback(
    const per_object_inflation_msgs::msg::PerObjectInflationArray::SharedPtr msg);
  void inflateObject(nav2_costmap_2d::Costmap2D & master_grid, const Obj & o);
  // Parameters
  std::string topic_;
  double cost_scaling_factor_;   // decay sharpness (like Nav2 InflationLayer's k)
  bool use_tf_;
  std::string target_frame_;     // costmap frame
  // Data
  std::vector<Obj> objects_;
  std::mutex mtx_;
  // ROS
  rclcpp::Subscription<per_object_inflation_msgs::msg::PerObjectInflationArray>::SharedPtr sub_;
  // TF
  std::shared_ptr<tf2_ros::Buffer> tf_buffer_;
  std::shared_ptr<tf2_ros::TransformListener> tf_listener_;
};
}  // namespace per_object_inflation_layer
#endif  // PER_OBJECT_INFLATION_LAYER__PER_OBJECT_INFLATION_LAYER_HPP_

