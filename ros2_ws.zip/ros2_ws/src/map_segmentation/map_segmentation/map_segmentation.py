#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import math
from collections import deque
import random
import numpy as np
import rclpy
from rclpy.node import Node
from nav_msgs.srv import GetMap
from visualization_msgs.msg import MarkerArray, Marker
from geometry_msgs.msg import Point
from per_object_inflation_msgs.msg import (
    PerObjectInflation,
    PerObjectInflationArray,
)
def quat_to_yaw(q):
    """Yaw (rotación sobre Z) desde un quaternion."""
    siny_cosp = 2.0 * (q.w * q.z + q.x * q.y)
    cosy_cosp = 1.0 - 2.0 * (q.y * q.y + q.z * q.z)
    return math.atan2(siny_cosp, cosy_cosp)
class MapSegmentation(Node):
    """Segmenta el OccupancyGrid en clusters y publica inflation por objeto."""
    def __init__(self):
        super().__init__('map_segmentation')
        # Parameters
        self.drop_border_clusters = self.declare_parameter(
            'drop_border_clusters', True
        ).value
        self.max_cluster_radius = self.declare_parameter(
            'max_cluster_radius', 4.0  # meters; <=0 disables the check
        ).value
        # Publishers
        self.marker_pub = self.create_publisher(
            MarkerArray, '/segmentation_markers', 10
        )
        self.infl_pub = self.create_publisher(
            PerObjectInflationArray, '/per_object_inflation', 10
        )
        # Cliente a map_server
        self.map_client = self.create_client(GetMap, '/map_server/map')
        while not self.map_client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Map server not available, waiting...')
        self.get_logger().info('Requesting map...')
        future = self.map_client.call_async(GetMap.Request())
        future.add_done_callback(self.map_callback)
    # ----------------------- Callbacks -----------------------
    def map_callback(self, future):
        try:
            response = future.result()
        except Exception as exc:  # noqa: BLE001
            self.get_logger().error(f'Failed to get map: {exc!r}')
            return
        map_msg = response.map
        width = map_msg.info.width
        height = map_msg.info.height
        resolution = map_msg.info.resolution
        origin = map_msg.info.origin
        self.get_logger().info(
            f'Got map ({width} x {height}), resolution={resolution:.4f}'
        )
        # OccupancyGrid: data index = x + y * width
        grid = np.array(map_msg.data, dtype=np.int16).reshape((height, width))
        occ_mask = grid > 50  # ocupadas
        self.get_logger().info(f'Occupied cells = {int(occ_mask.sum())}')
        clusters = self.segment_objects(grid)
        # Precompute rotación de origin
        yaw = quat_to_yaw(origin.orientation)
        cos_y = math.cos(yaw)
        sin_y = math.sin(yaw)
        def cell_center_world(r, c):
            """Centro de celda (r,c) → coords mundo en frame 'map'."""
            cx = (c + 0.5) * resolution
            cy = (r + 0.5) * resolution
            rx = cos_y * cx - sin_y * cy
            ry = sin_y * cx + cos_y * cy
            x = origin.position.x + rx
            y = origin.position.y + ry
            return x, y
        # --------- Publica markers para visualización ---------
        markers = MarkerArray()
        marker_id = 0
        for i, cluster in enumerate(clusters):
            color = [random.random() for _ in range(3)]
            for r, c in cluster:
                x, y = cell_center_world(r, c)
                m = Marker()
                m.header.frame_id = 'map'
                m.header.stamp = self.get_clock().now().to_msg()
                m.ns = 'segmentation'
                m.id = marker_id
                marker_id += 1
                m.type = Marker.CUBE
                m.action = Marker.ADD
                m.pose.position.x = float(x)
                m.pose.position.y = float(y)
                m.pose.position.z = 0.0
                m.pose.orientation.w = 1.0
                m.scale.x = resolution
                m.scale.y = resolution
                m.scale.z = 0.02  # fino para no tapar
                m.color.r = float(color[0])
                m.color.g = float(color[1])
                m.color.b = float(color[2])
                m.color.a = 0.9
                markers.markers.append(m)
        self.marker_pub.publish(markers)
        self.get_logger().info(
            f'Published {len(markers.markers)} markers for {len(clusters)} clusters'
        )
        # --------- Publica PerObjectInflationArray ---------
        objects_msg = PerObjectInflationArray()
        objects_msg.header.frame_id = 'map'
        objects_msg.header.stamp = self.get_clock().now().to_msg()
        skipped = 0
        for i, cluster in enumerate(clusters):
            rs = cluster[:, 0].astype(np.float32)
            cs = cluster[:, 1].astype(np.float32)
            touches_border = bool(
                self.drop_border_clusters and (
                    rs.min() <= 0 or
                    rs.max() >= (height - 1) or
                    cs.min() <= 0 or
                    cs.max() >= (width - 1)
                )
            )
            if touches_border:
                skipped += 1
                self.get_logger().debug(
                    f'Skipping cluster {i}: touches map border (cells={cluster.shape[0]})'
                )
                continue
            # Centroide en índice de celda
            r_c = float(rs.mean())
            c_c = float(cs.mean())
            # Centro en coords mundo (redondeamos a celda más cercana)
            x_c, y_c = cell_center_world(int(round(r_c)), int(round(c_c)))
            # Radio: distancia máxima al centro en pix * resolution (+0.5 celda margen)
            d_pix = float(np.sqrt((rs - r_c) ** 2 + (cs - c_c) ** 2).max())
            radius_m = float((d_pix + 0.5) * resolution)
            if self.max_cluster_radius > 0.0 and radius_m > self.max_cluster_radius:
                skipped += 1
                self.get_logger().debug(
                    f'Skipping cluster {i}: radius {radius_m:.2f} m > {float(self.max_cluster_radius):.2f} m limit'
                )
                continue
            obj = PerObjectInflation()
            obj.id = i
            obj.center = Point(x=x_c, y=y_c, z=0.0)
            if obj.id ==2:
                obj.radius = radius_m*2

            elif obj.id ==1:
                obj.radius = radius_m*3

            elif obj.id ==3:
                obj.radius = radius_m*4
            
            elif obj.id ==4:
                obj.radius = radius_m*4

            else:
                obj.radius = radius_m
            objects_msg.objects.append(obj)
        self.infl_pub.publish(objects_msg)
        if skipped:
            self.get_logger().info(
                f'Published {len(objects_msg.objects)} objects (skipped {skipped} clusters)'
            )
        self.get_logger().info(
            f'Published {len(objects_msg.objects)} per-object inflation entries'
        )
    # ----------------------- Utils -----------------------
    def segment_objects(self, grid):
        """BFS de 4-conectividad para componentes conexas (>50)."""
        height, width = grid.shape
        visited = np.zeros((height, width), dtype=bool)
        clusters = []
        def neighbors(r, c):
            for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                nr, nc = r + dr, c + dc
                if 0 <= nr < height and 0 <= nc < width:
                    yield nr, nc
        for r in range(height):
            for c in range(width):
                if grid[r, c] > 50 and not visited[r, c]:
                    cluster = []
                    q = deque([(r, c)])
                    visited[r, c] = True
                    while q:
                        cr, cc = q.popleft()
                        cluster.append((cr, cc))
                        for nr, nc in neighbors(cr, cc):
                            if grid[nr, nc] > 50 and not visited[nr, nc]:
                                visited[nr, nc] = True
                                q.append((nr, nc))
                    if len(cluster) >= 5:  # filtra clusters pequeños
                        clusters.append(np.array(cluster))
        return clusters
def main(args=None):
    rclpy.init(args=args)
    node = MapSegmentation()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()
if __name__ == '__main__':
    main()
